
const express = require('express');
const http = require('http');
const socketIO = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

let players = {};

io.on('connection', socket => {
    console.log('New player connected: ' + socket.id);

    players[socket.id] = {
        x: 100,
        y: 100,
        angle: 0,
        speed: 0
    };

    socket.emit('currentPlayers', players);
    socket.broadcast.emit('newPlayer', { id: socket.id, data: players[socket.id] });

    socket.on('move', data => {
        if (players[socket.id]) {
            players[socket.id] = data;
            socket.broadcast.emit('playerMoved', { id: socket.id, data: data });
        }
    });

    socket.on('disconnect', () => {
        console.log('Player disconnected: ' + socket.id);
        delete players[socket.id];
        io.emit('playerDisconnected', socket.id);
    });
});

app.use(express.static('public'));

server.listen(3000, () => {
    console.log('Server listening on port 3000');
});
